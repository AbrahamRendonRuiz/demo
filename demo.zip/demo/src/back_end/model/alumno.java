/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package back_end.model;

import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author ccgja
 */
public class alumno {
    private StringProperty codigo;
    private StringProperty nombre;
    private IntegerProperty edad;
    private FloatProperty promedio;

    public alumno() {
        codigo=new SimpleStringProperty();
        nombre = new SimpleStringProperty();
        edad = new SimpleIntegerProperty();
        promedio = new SimpleFloatProperty();
        
    }

    public alumno(String codigo, String nombre, Integer edad, Float promedio) {
        this();
//  this.codigo = codigo;
//  this.nombre = nombre;
//  this.edad = edad;
//  this.promedio = promedio;
    this.codigo.set(codigo);
    this.nombre.set(nombre);
    this.edad.set(edad);
    this.promedio.set(promedio);
    }

   

    public String getCodigo() {
        return codigo.get();
    }

    public void setCodigo(String codigo) {
        this.codigo.set(codigo);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public Integer getEdad() {
        return edad.get();
    }

    public void setEdad(Integer edad) {
        this.edad.set(edad);
    }

    public Float getPromedio() {
        return promedio.get();
    }

    public void setPromedio(Float promedio) {
        this.promedio.set(promedio);
    }

    @Override
    public String toString() {
        return "alumno{" + "codigo=" + codigo.get() + ", nombre=" + nombre.get() + ", edad=" + edad.get() + ", promedio=" + promedio.get() + '}';
    }
    
}
