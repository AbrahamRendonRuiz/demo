/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package back_end.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author ccgja
 */
public class conexion {
    private Connection cnn=null;
    private String user="root";
    private String password="rootroot";
    private String url="jdbc:mysql://localhost:3306/demo"+"?verifyServerCertificate=false"+"&useSSL=false"+"&requiereSSL=false";
    private String JDBC="com.mysql.cj.jdbc.Driver";
    public conexion(){
        try {
            System.out.println("");
            Class.forName(JDBC);
            cnn = DriverManager.getConnection(url, user, password);
            if (cnn != null) {
                System.out.println("conexion exitosa"+ cnn.hashCode());
            }
        } catch (Exception e) {
            System.out.println("no se pudo conectar"+ e.getMessage());
            e.printStackTrace();
        }
    
    }

    public Connection getCnn() {
        return cnn;
    }
    
}
