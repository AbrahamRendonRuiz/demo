/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package back_end.jdbc;

import back_end.model.alumno;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static front_end.AlumnoFXMLController.conex;

/**
 *
 * @author ccgja
 */
public class AlumnoDAO {
   
    private static final String SQL_INSERT = "INSERT INTO Alumno (Codigo, Nombre, Edad, Promedio) Values (?,?,?,?)";
    private static final String SQL_SELECT = "Select * From Alumno where codigo=?";
    private static final String SQL_UPDATE = "UPDATE Alumno SET Nombre = ?, edad = ?, promedio = ? WHERE codigo = ?";
    private static final String SQL_DELETE = "DELETE FROM Alumno where codigo = ?";
    private static final String SQL_SELECT_ALL = "Select * From Alumno";
    public void Create(alumno dto)throws SQLException{
      PreparedStatement ps = null; 
      
      try {
          ps=conex.getCnn().prepareStatement(SQL_INSERT);
          
          ps.setString(1, dto.getCodigo());
          ps.setString(2, dto.getNombre());
          ps.setInt(3, dto.getEdad());
          ps.setFloat(4, dto.getPromedio());
          ps.executeUpdate();
      } finally{
       
      }
  }
    public alumno Buscar(alumno dto)throws SQLException{
        PreparedStatement ps = null;
        ResultSet rs = null;
        try{
            ps = conex.getCnn().prepareStatement(SQL_SELECT);
            ps.setString(1, dto.getCodigo());
            rs = ps.executeQuery();
            List results = getResult(rs);
            if(results.size()>0){
                alumno alu = new alumno();
                alu = (alumno)(results.get(0));
//                alu.setNombre(results.get(1).toString());
//                int edad = Integer.parseInt(results.get(3).toString());
//                alu.setEdad(edad);
//                float prome = Float.parseFloat(results.get(4).toString());
//                alu.setPromedio(prome);
                return alu;
                
            }else{
                return null;
            }
        }finally{
            
        }
    }
    public void update (alumno dto)throws SQLException{
        PreparedStatement ps = null;
        try{
        ps = conex.getCnn().prepareStatement(SQL_UPDATE);
        ps.setString(4, dto.getCodigo());
        ps.setString(1, dto.getNombre());
        ps.setInt(2, dto.getEdad());
        ps.setFloat(3, dto.getPromedio());
        ps.executeUpdate();
        }finally{
            
        }
    }
    public void delete (alumno dto) throws SQLException{
        PreparedStatement ps = null;
        try{
            ps = conex.getCnn().prepareStatement(SQL_DELETE);
            ps.setString(1, dto.getCodigo());
            ps.executeUpdate();
        }finally{
            
        }
    }
  public List loadALL()throws SQLException{
  PreparedStatement ps=null;
  ResultSet rs = null;
  try{
      ps = conex.getCnn().prepareStatement(SQL_SELECT_ALL);
      rs = ps.executeQuery();
      List results = getResult(rs);
      if(results.size()>0){
          return results;
      }else{
          return null;
      }
  }finally{
      
  }
  }
  public List getResult(ResultSet rs) throws SQLException{
  List results = new ArrayList();
      while (rs.next()) {          
          alumno dto= new alumno();
          dto.setCodigo(rs.getString("Codigo"));
          dto.setNombre(rs.getString("Nombre"));
          dto.setEdad(rs.getInt("Edad"));
          dto.setPromedio(rs.getFloat("Promedio"));
          results.add(dto);         
      }
      return results;
  }

}
