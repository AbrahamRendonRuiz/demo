/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package front_end;

import back_end.jdbc.AlumnoDAO;
import back_end.jdbc.conexion;
import back_end.model.alumno;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author ccgja
 */
public class AlumnoFXMLController implements Initializable {

    public AlumnoDAO dao;
    public alumno dto;
    public static conexion conex;
    @FXML
    private TextField Txt_Nombre;
    @FXML
    private TextField Txt_Promedio;
    @FXML
    private TextField Txt_Edad;
    @FXML
    private TextField Txt_Codigo;
    @FXML
    private Button modi;
    @FXML
    private Button delete;
    @FXML
    private TableView<alumno> table1;
    @FXML
    private Button list;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //conex=new conexion();
        modi.setDisable(true);
        conex = new conexion();
        dao = new AlumnoDAO();
        TableColumn<alumno, String> colCodigo = new TableColumn<>("Codigo");
        TableColumn<alumno, String> colNombre = new TableColumn<>("nombre");
        TableColumn<alumno, String> conEdad = new TableColumn<>("edad");
        TableColumn<alumno, String> conPromedio = new TableColumn<>("promedio");
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        conEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));
        conPromedio.setCellValueFactory(new PropertyValueFactory<>("promedio"));
        table1.getColumns().addAll(colCodigo, colNombre, conEdad, conPromedio);

    }

    @FXML
    private void Registrarbtn(ActionEvent event) {
        dto = new alumno();

        dto.setCodigo(Txt_Codigo.getText());
        dto.setNombre(Txt_Nombre.getText());
        dto.setEdad(Integer.parseInt(Txt_Edad.getText()));
        dto.setPromedio(Float.parseFloat(Txt_Promedio.getText()));
        try {
            dao.Create(dto);
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("EXITO");
            alert.setHeaderText("EXITO EN DB");
            alert.setContentText("Agregado base");
            alert.show();
            Txt_Codigo.setText("");
            Txt_Edad.setText("");
            Txt_Nombre.setText("");
            Txt_Promedio.setText("");
        } catch (SQLException e) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
        }
    }

    @FXML
    private void Salidabtn(ActionEvent event) {
    }

    @FXML
    private void Buscar(ActionEvent event) throws SQLException {
        dto = new alumno();

        dto.setCodigo(Txt_Codigo.getText());
        try {
            dto = dao.Buscar(dto);
            if (dto != null) {
                Txt_Codigo.setText(dto.getCodigo());
                Txt_Edad.setText(dto.getEdad().toString());
                Txt_Nombre.setText(dto.getNombre());
                Txt_Promedio.setText(dto.getPromedio().toString());
                modi.setDisable(false);
            } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("ERROR");
                alert.setHeaderText("DATA NOT FOUNDED");
                alert.setContentText("CHECK YOUR DATA!");

                alert.showAndWait();
            }
        } finally {

        }
    }

    @FXML
    private void modificar(ActionEvent event) throws SQLException {
        dto = new alumno();

        dto.setCodigo(Txt_Codigo.getText());
        dto.setNombre(Txt_Nombre.getText());
        dto.setEdad(Integer.parseInt(Txt_Edad.getText()));
        dto.setPromedio(Float.parseFloat(Txt_Promedio.getText()));
        Txt_Codigo.setText("");
        Txt_Edad.setText("");
        Txt_Nombre.setText("");
        Txt_Promedio.setText("");
        try {
            dao.update(dto);
            modi.setDisable(true);
        } catch (SQLException e) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error!");
            alert.setHeaderText("UPDATE ERROR");
            alert.setContentText("FALLO en actualizacion de datos");

            alert.showAndWait();
        }
    }

    @FXML
    private void borrar(ActionEvent event) {
        dto = new alumno();

        dto.setCodigo(Txt_Codigo.getText());
        try {
            dao.delete(dto);
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("EXITO");
            alert.setHeaderText("SUCCESFULL");
            alert.setContentText("Se a eliminado correctamente");
            alert.show();
        } catch (SQLException e) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error!");
            alert.setHeaderText("DELETE ERROR");
            alert.setContentText("FALLO en borrar dato");
        }
    }

    @FXML
    private void listar(ActionEvent event) throws SQLException {
        List lista = dao.loadALL();
        table1.getItems().clear();
        table1.getItems().addAll(lista);
    }

    @FXML
    private void Limpiar(ActionEvent event) {
        Txt_Codigo.setText("");
        Txt_Edad.setText("");
        Txt_Nombre.setText("");
        Txt_Promedio.setText("");
        modi.setDisable(true);
    }

}
